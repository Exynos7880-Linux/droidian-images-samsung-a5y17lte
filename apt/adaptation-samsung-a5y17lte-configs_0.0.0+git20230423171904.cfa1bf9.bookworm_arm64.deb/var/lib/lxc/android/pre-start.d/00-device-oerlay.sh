#!/bin/sh

mount -o bind /usr/lib/droid-system-overlay/etc/init/init.disabled.rc /android/system/etc/init/init.disabled.rc
